export const dummyUsers = [{ username: "Janardhan", password: "Cagl@2024" }];
