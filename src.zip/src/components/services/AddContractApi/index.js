import serviceUtil from "../ServiceUtil";

const AddRentContractDetails = (payload) => {
  return serviceUtil
    .post(`insertcontract`, payload)
    .then((res) => {
      console.log(res, "res");
      const data = res && res.data;
      return { data };
    })
    .catch((err) => {
      const errRes = (err && err.response && err.response.data) || {
        message: "ERROR",
      };
      return { errRes };
    });
};

const getTenureDetails = (params1, params2) => {
  return serviceUtil
    .get(`getenure?startDate=${params1}&EndDate=${params2}`)
    .then((res) => {
      // console.log(res, "BranchDatares");
      const data = res.data;
      return { data };
    })
    .catch((err) => {
      const errRes = err;
      return { errRes };
    });
};
export { AddRentContractDetails,getTenureDetails };
