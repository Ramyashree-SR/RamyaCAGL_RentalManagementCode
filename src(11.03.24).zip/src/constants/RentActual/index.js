const RentActualColumn = [
    { id: "contractID", label: "ID", align: "center" },
    { id: "branchID", label: "Branch ID", align: "center" },
    { id: "monthYear", label: "Month/Year", align: "center" },
    { id: "Amount", label: "Amount", align: "center" },
    { id: "month", label: "Month", align: "center" },
    { id: "startDate", label: "Rent Start Date", align: "center" },
    { id: "endDate", label: "Rent End Date", align: "center" },
  ];
  export { RentActualColumn };