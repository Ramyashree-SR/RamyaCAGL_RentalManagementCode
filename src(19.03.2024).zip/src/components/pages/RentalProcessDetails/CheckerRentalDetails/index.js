import React from 'react'

const CheckerRentalDetails = () => {
  return (
    <div>CheckerRentalDetails</div>
  )
}

export default CheckerRentalDetails