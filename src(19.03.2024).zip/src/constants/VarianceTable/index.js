const varianceColumns = [
  { id: "contractID", label: "ID", align: "center" },
  { id: "branchID", label: "Branch ID", align: "center" },
  { id: "lesseeBranchName", label: "Branch Name", align: "center" },
  { id: "rentStartDate", label: "Rent Start Date", align: "center" },
  { id: "rentEndDate", label: "Rent  End Date", align: "center" },
  { id: "year", label: "Year", align: "center" },
  { id: "month", label: "Month", align: "center" },
  { id: "varianceAmount", label: "Variance Amount", align: "center" },
];

export { varianceColumns };
